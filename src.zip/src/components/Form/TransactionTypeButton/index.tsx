import React from 'react';
import { TouchableOpacityProps } from 'react-native';

import {
    Container,
    Icon,
    Title
} from './styles';

interface Props extends TouchableOpacityProps{
    title: string
}

export default function TransactionTypeButton({ title, ...rest} : Props) {
    return (
        <Container {...rest}>
            <Icon name='arrow-up-circle'/>

            <Title>
                {title}
            </Title>
        </Container>
    );
} 